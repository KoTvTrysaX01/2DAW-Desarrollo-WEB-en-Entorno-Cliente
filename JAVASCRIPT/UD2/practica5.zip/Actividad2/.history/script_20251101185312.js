let form = document.getElementById("registarForm");
