window.on
let form = document.getElementById("registarForm");
