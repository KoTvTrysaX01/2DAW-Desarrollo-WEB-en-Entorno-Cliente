window.onload = function {
  let form = document.getElementById("registarForm");
  let nombre = 

}
