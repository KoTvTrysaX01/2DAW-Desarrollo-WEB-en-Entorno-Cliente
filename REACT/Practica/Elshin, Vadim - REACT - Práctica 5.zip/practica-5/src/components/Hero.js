export default function Hero() {
  return (
    <>
      <div className="px-4 py-5 my-5 text-center">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="65"
          height="65"
          fill="currentColor"
          class="bi bi-book-half text-info"
          viewBox="0 0 16 16"
        >
          <path d="M8.5 2.687c.654-.689 1.782-.886 3.112-.752 1.234.124 2.503.523 3.388.893v9.923c-.918-.35-2.107-.692-3.287-.81-1.094-.111-2.278-.039-3.213.492zM8 1.783C7.015.936 5.587.81 4.287.94c-1.514.153-3.042.672-3.994 1.105A.5.5 0 0 0 0 2.5v11a.5.5 0 0 0 .707.455c.882-.4 2.303-.881 3.68-1.02 1.409-.142 2.59.087 3.223.877a.5.5 0 0 0 .78 0c.633-.79 1.814-1.019 3.222-.877 1.378.139 2.8.62 3.681 1.02A.5.5 0 0 0 16 13.5v-11a.5.5 0 0 0-.293-.455c-.952-.433-2.48-.952-3.994-1.105C10.413.809 8.985.936 8 1.783" />
        </svg>
        <h1 class="display-5 fw-bold text-body-emphasis">Mundo de Libros</h1>
        <div class="col-lg-6 mx-auto">
          <p class="lead mb-4">
            Minim sint nostrud fugiat duis esse ipsum voluptate do nisi magna
            laborum id laborum velit. Ex laboris labore sit incididunt et eu
            sint. Fugiat ullamco Lorem sint in sunt qui ad et. Fugiat labore
            incididunt in id tempor esse. Minim do deserunt consectetur amet
            consequat occaecat nisi cillum nulla.
          </p>
          <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
            <button type="button" class="btn btn-primary btn-lg px-4 gap-3">
              Primary button
            </button>
            <button type="button" class="btn btn-outline-secondary btn-lg px-4">
              Secondary
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
